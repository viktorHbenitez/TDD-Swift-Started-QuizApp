//
//  Move.swift
//  FizzBuzz
//
//  Created by Yvette on 20/09/2018.
//  Copyright © 2018 yvette. All rights reserved.
//

import Foundation

enum Move {
    case number
    case fizz
    case buzz
    case fizzBuzz
}
